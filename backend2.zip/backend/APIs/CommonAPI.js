// CommonAPI.js

import exp from 'express';
import { hash, compare } from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { UserModel } from '../models/UserModel.js';
import { verifyToken } from '../middlewares/verifyToken.js';
import { upload } from "../config/multer.js";
import { uploadToCloudinary } from "../config/cloudinaryUpload.js";
import cloudinary from "../config/cloudinary.js";
const { sign } = jwt;

export const commonApp = exp.Router();

// register
commonApp.post("/users", upload.single("profileImage"), async (req, res, next) => {
    let cloudinaryResult
    try {
        const newUser = req.body
        const allowedRoles = ["USER"]
        if (newUser.role && !allowedRoles.includes(newUser.role))
            return res.status(400).json({ message: "Invalid role" })
        // upload image if exists
        if (req.file) {
            cloudinaryResult = await uploadToCloudinary(req.file.buffer)
            newUser.profileImage = cloudinaryResult?.secure_url
        }
        // hash password
        newUser.password = await hash(newUser.password, 10)
        // save user
        const createdUser = await UserModel.create(newUser)
        // create token
        const token = sign(
            {
                id: createdUser._id,
                email: createdUser.email,
                role: createdUser.role
            },
            process.env.SECRET_KEY,
            {
                expiresIn: "10h"
            }
        )
        // set token to cookie
        res.cookie("token", token, {
            httpOnly: true,
            secure: false,
            sameSite: "lax"
        })
        // convert document into JS object
        const userObj = createdUser.toObject()
        // remove password
        delete userObj.password
        // send response
        res.status(201).json({
            message: "User created successfully",
            payload: userObj
        })
    } catch (err) {
        console.log("Register error:", err.message)
        // rollback image
        if (cloudinaryResult?.public_id)
            await cloudinary.uploader.destroy(cloudinaryResult.public_id)
        next(err)
    }
})

// login
commonApp.post("/login", async (req, res) => {
    try {
        // get email and password from body
        const { email, password } = req.body
        // find user by email
        const user = await UserModel.findOne({ email })
        // no user found
        if (!user)
            return res.status(400).json({
                message: "Invalid email"
            })
        // compare password
        const isMatched = await compare(password, user.password)
        // password not matched
        if (!isMatched)
            return res.status(400).json({
                message: "Invalid password"
            })
        // create JWT token
        const token = sign(
            {
                id: user._id,
                email: user.email,
                role: user.role
            },
            process.env.SECRET_KEY,
            {
                expiresIn: "10h"
            }
        )
        // store token in cookie
        res.cookie("token", token, {
            httpOnly: true,
            secure: false,
            sameSite: "lax"
        })
        // convert document into JS object
        const userObj = user.toObject()
        // remove password
        delete userObj.password
        // send response
        res.status(200).json({
            message: "Login successful",
            payload: userObj
        })
    } catch (err) {
        res.status(500).json({
            message: err.message
        })
    }
})

// logout
commonApp.get("/logout", (req, res) => {
    // delete token from cookie storage
    res.clearCookie("token", {
        httpOnly: true,
        secure: false,
        sameSite: "lax"
    })
    // send response
    res.status(200).json({
        message: "Logout successful"
    })
})

// change password
commonApp.put("/password", verifyToken("USER", "ADMIN"), async (req, res) => {
        try {
            // get current and new password
            const {
                currentPassword,
                newPassword
            } = req.body
            // find user using token id
            const user = await UserModel.findById(req.user?.id)
            // user not found
            if (!user)
                return res.status(404).json({
                    message: "User not found"
                })
            // check if old and new passwords are same
            if (currentPassword === newPassword)
                return res.status(400).json({
                    message: "New password cannot be same as old password"
                })
            // compare current password
            const isMatch = await compare(
                currentPassword,
                user.password
            )
            // incorrect password
            if (!isMatch)
                return res.status(400).json({
                    message: "Current password incorrect"
                })
            // hash new password
            user.password = await hash(newPassword, 10)
            await user.save()
            // send response
            res.status(200).json({
                message: "Password updated successfully"
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// check authentication / page refresh
commonApp.get( "/check-auth",verifyToken("USER", "ADMIN"),async (req, res) => {
        try {
            // find user using token id
            const user = await UserModel
                .findById(req.user?.id)
                .select("-password")
            // user not found
            if (!user)
                return res.status(404).json({
                    message: "User not found"
                })
            // send user details
            res.status(200).json({
                message: "Authenticated",
                payload: user
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)