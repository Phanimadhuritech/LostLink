// MatchAPI.js

import exp from 'express';
import { MatchModel } from '../models/MatchModel.js';
import { ItemModel } from '../models/ItemModel.js';
import { verifyToken } from '../middlewares/verifyToken.js';
export const matchApp = exp.Router();

// find matches for a lost item
matchApp.get(
    "/lost/:itemId",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get lost item id
            const { itemId } = req.params
            // find lost item
            const lostItem = await ItemModel.findById(itemId)
            // item not found
            if (!lostItem)
                return res.status(404).json({
                    message: "Item not found"
                })
            // check item type
            if (lostItem.type !== "LOST")
                return res.status(400).json({
                    message: "Only lost items can be matched"
                })
            // find active found items
            const foundItems = await ItemModel.find({
                type: "FOUND",
                status: "ACTIVE"
            })
            const matches = []
            // compare lost item with found items
            for (const foundItem of foundItems) {
                let score = 0
                let matchedFields = []
                // compare category
                if (
                    lostItem.category === foundItem.category
                ) {
                    score += 25
                    matchedFields.push("category")
                }
                // compare item name
                if (
                    lostItem.itemName
                        .toLowerCase()
                        .includes(foundItem.itemName.toLowerCase()) ||
                    foundItem.itemName
                        .toLowerCase()
                        .includes(lostItem.itemName.toLowerCase())
                ) {
                    score += 25
                    matchedFields.push("itemName")
                }
                // compare location
                if (
                    lostItem.location
                        .toLowerCase()
                        .includes(foundItem.location.toLowerCase()) ||
                    foundItem.location
                        .toLowerCase()
                        .includes(lostItem.location.toLowerCase())
                ) {
                    score += 20
                    matchedFields.push("location")
                }
                // compare date
                const lostDate = new Date(lostItem.date)
                const foundDate = new Date(foundItem.date)
                const difference =
                    Math.abs(lostDate - foundDate) /
                    (1000 * 60 * 60 * 24)
                if (difference <= 2) {
                    score += 15
                    matchedFields.push("date")
                }
                // compare description keywords
                const lostDescription =
                    lostItem.description.toLowerCase()
                const foundDescription =
                    foundItem.description.toLowerCase()
                const lostWords =
                    lostDescription.split(" ")
                const commonWords =
                    lostWords.filter(word =>
                        word.length > 3 &&
                        foundDescription.includes(word)
                    )
                if (commonWords.length > 0) {
                    score += 15
                    matchedFields.push("description")
                }
                // only store meaningful matches
                if (score >= 40) {
                    const existingMatch =
                        await MatchModel.findOne({
                            lostItemId: lostItem._id,
                            foundItemId: foundItem._id
                        })
                    if (!existingMatch) {
                        const newMatch =
                            await MatchModel.create({
                                lostItemId: lostItem._id,
                                foundItemId: foundItem._id,
                                matchScore: score,
                                matchedFields: matchedFields,
                                status: "PENDING"
                            })
                        matches.push(newMatch)
                    } else {
                        matches.push(existingMatch)
                    }
                }
            }
            // send matches
            res.status(200).json({
                message: "Matching completed successfully",
                payload: matches
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// get matches for a lost item
matchApp.get(
    "/lost/:itemId/results",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item id
            const { itemId } = req.params
            // find matches
            const matches = await MatchModel.find({
                lostItemId: itemId
            })
            .populate({
                path: "lostItemId",
                select: "-verificationAnswer"
            })
            .populate({
                path: "foundItemId",
                select: "-verificationAnswer"
            })
            .sort({ matchScore: -1 })
            // send response
            res.status(200).json({
                message: "Matches retrieved successfully",
                payload: matches
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// get matches for a found item
matchApp.get(
    "/found/:itemId",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get found item id
            const { itemId } = req.params
            // find matches
            const matches = await MatchModel.find({
                foundItemId: itemId
            })
            .populate({
                path: "lostItemId",
                select: "-verificationAnswer"
            })
            .populate({
                path: "foundItemId",
                select: "-verificationAnswer"
            })
            .sort({ matchScore: -1 })
            // send response
            res.status(200).json({
                message: "Matches retrieved successfully",
                payload: matches
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// confirm match
matchApp.put(
    "/:matchId/confirm",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get match id
            const { matchId } = req.params
            // find match
            const match = await MatchModel.findById(matchId)
            // match not found
            if (!match)
                return res.status(404).json({
                    message: "Match not found"
                })
            // find lost item
            const lostItem =
                await ItemModel.findById(match.lostItemId)
            // find found item
            const foundItem =
                await ItemModel.findById(match.foundItemId)
            // items not found
            if (!lostItem || !foundItem)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only users involved with the items can confirm
            const userId = req.user?.id
            if (
                lostItem.postedBy.toString() !== userId &&
                foundItem.postedBy.toString() !== userId &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to confirm this match"
                })
            // update match status
            match.status = "CONFIRMED"
            await match.save()
            // update item statuses
            lostItem.status = "MATCHED"
            foundItem.status = "MATCHED"
            await lostItem.save()
            await foundItem.save()
            // send response
            res.status(200).json({
                message: "Match confirmed successfully",
                payload: match
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// reject match
matchApp.put(
    "/:matchId/reject",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get match id
            const { matchId } = req.params
            // find match
            const match = await MatchModel.findById(matchId)
            // match not found
            if (!match)
                return res.status(404).json({
                    message: "Match not found"
                })
            // update status
            match.status = "REJECTED"
            await match.save()
            // send response
            res.status(200).json({
                message: "Match rejected successfully",
                payload: match
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)