// ItemAPI.js

import exp from 'express';
import mongoose from 'mongoose';
import { ItemModel } from '../models/ItemModel.js';
import { verifyToken } from '../middlewares/verifyToken.js';
export const itemApp = exp.Router();

// CREATE LOST / FOUND ITEM
itemApp.post(
    "/",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item details from body
            const newItem = req.body
            // add logged-in user as poster
            newItem.postedBy = req.user?.id
            // validate item type
            if (!["LOST", "FOUND"].includes(newItem.type))
                return res.status(400).json({
                    message: "Type must be LOST or FOUND"
                })
            // create item
            const createdItem = await ItemModel.create(newItem)
            // convert document to object
            const itemObj = createdItem.toObject()
            // do not send verification answer to frontend
            delete itemObj.verificationAnswer
            // send response
            res.status(201).json({
                message: "Item posted successfully",
                payload: itemObj
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// GET ALL ACTIVE ITEMS
itemApp.get(
    "/",
    async (req, res) => {
        try {
            // get query parameters
            const {
                type,
                category,
                search,
                location
            } = req.query
            // create filter object
            const filter = {
                status: "ACTIVE"
            }
            // filter by LOST / FOUND
            if (type) {
                const itemType = type.toUpperCase()
                if (!["LOST", "FOUND"].includes(itemType))
                    return res.status(400).json({
                        message: "Type must be LOST or FOUND"
                    })
                filter.type = itemType
            }
            // filter by category
            if (category)
                filter.category = category.toUpperCase()
            // filter by location
            if (location)
                filter.location = {
                    $regex: location,
                    $options: "i"
                }
            // search by item name or description
            if (search) {
                filter.$or = [

                    {
                        itemName: {

                            $regex: search,

                            $options: "i"

                        }
                    },

                    {
                        description: {

                            $regex: search,

                            $options: "i"

                        }
                    }

                ]
            }
            // find items
            const items = await ItemModel.find(filter)
                .populate("postedBy", "name email")
                .select("-verificationAnswer")
                .sort({ createdAt: -1 })
            // send response
            res.status(200).json({
                message: "Items retrieved successfully",
                payload: items
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// GET MY ITEMS
itemApp.get(
    "/my-items",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // find items posted by logged-in user
            const items = await ItemModel.find({
                postedBy: req.user?.id
            })
                .select("-verificationAnswer")
                .sort({ createdAt: -1 })
            // send response
            res.status(200).json({
                message: "Your items retrieved successfully",
                payload: items
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// GET SINGLE ITEM
itemApp.get(
    "/:itemId",
    async (req, res) => {
        try {
            // get item id
            const { itemId } = req.params
            // check valid MongoDB ObjectId
            if (!mongoose.Types.ObjectId.isValid(itemId))
                return res.status(400).json({
                    message: "Invalid item ID"
                })
            // find item
            const item = await ItemModel.findById(itemId)
                .populate("postedBy", "name email")
                .select("-verificationAnswer")
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // send response
            res.status(200).json({
                message: "Item retrieved successfully",
                payload: item
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// UPDATE ITEM
itemApp.put(
    "/:itemId",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item id
            const { itemId } = req.params
            // check valid MongoDB ObjectId
            if (!mongoose.Types.ObjectId.isValid(itemId))
                return res.status(400).json({
                    message: "Invalid item ID"
                })
            // find item
            const item = await ItemModel.findById(itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only owner or admin can update item
            if (
                item.postedBy.toString() !== req.user?.id &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to update this item"
                })
            // create update object
            const updateData = { ...req.body }
            // user should not change postedBy
            delete updateData.postedBy
            // user should not directly change status
            delete updateData.status
            // update item
            const updatedItem = await ItemModel.findByIdAndUpdate(
                itemId,
                updateData,
                {
                    new: true,
                    runValidators: true
                }
            )
                .select("-verificationAnswer")
            // send response
            res.status(200).json({
                message: "Item updated successfully",
                payload: updatedItem
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// DELETE ITEM
itemApp.delete(
    "/:itemId",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item id
            const { itemId } = req.params
            // check valid MongoDB ObjectId
            if (!mongoose.Types.ObjectId.isValid(itemId))
                return res.status(400).json({
                    message: "Invalid item ID"
                })
            // find item
            const item = await ItemModel.findById(itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only owner or admin can delete item
            if (
                item.postedBy.toString() !== req.user?.id &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to delete this item"
                })
            // delete item
            await ItemModel.findByIdAndDelete(itemId)
            // send response
            res.status(200).json({
                message: "Item deleted successfully"
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// MARK ITEM AS RETURNED
itemApp.put(
    "/:itemId/returned",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item id
            const { itemId } = req.params
            // check valid MongoDB ObjectId
            if (!mongoose.Types.ObjectId.isValid(itemId))
                return res.status(400).json({
                    message: "Invalid item ID"
                })
            // find item
            const item = await ItemModel.findById(itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only owner or admin can mark returned
            if (
                item.postedBy.toString() !== req.user?.id &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to update this item"
                })
            // update status
            item.status = "RETURNED"
            await item.save()
            // convert to object
            const itemObj = item.toObject()
            // don't send verification answer
            delete itemObj.verificationAnswer
            // send response
            res.status(200).json({
                message: "Item marked as returned successfully",
                payload: itemObj
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)