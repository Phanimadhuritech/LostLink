// ClaimAPI.js

import exp from 'express';
import { ClaimModel } from '../models/ClaimModel.js';
import { ItemModel } from '../models/ItemModel.js';
import { verifyToken } from '../middlewares/verifyToken.js';
export const claimApp = exp.Router();

// create claim
claimApp.post(
    "/",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get item id and answer from body
            const { itemId, answer } = req.body
            // find item
            const item = await ItemModel.findById(itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only FOUND items can be claimed
            if (item.type !== "FOUND")
                return res.status(400).json({
                    message: "Only found items can be claimed"
                })
            // check item status
            if (item.status !== "ACTIVE")
                return res.status(400).json({
                    message: "This item is no longer available for claiming"
                })
            // user cannot claim their own post
            if (item.postedBy.toString() === req.user?.id)
                return res.status(400).json({
                    message: "You cannot claim your own item"
                })
            // check if user already submitted a claim
            const existingClaim = await ClaimModel.findOne({
                itemId: itemId,
                claimantId: req.user?.id
            })
            if (existingClaim)
                return res.status(400).json({
                    message: "You have already submitted a claim for this item"
                })
            // create claim
            const newClaim = await ClaimModel.create({
                itemId: itemId,
                claimantId: req.user?.id,
                answer: answer
            })
            // send response
            res.status(201).json({
                message: "Claim submitted successfully",
                payload: newClaim
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// get my claims
claimApp.get(
    "/my-claims",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // find claims created by logged-in user
            const claims = await ClaimModel.find({
                claimantId: req.user?.id
            })
            .populate("itemId")
            .sort({ createdAt: -1 })
            // send response
            res.status(200).json({
                message: "Claims retrieved successfully",
                payload: claims
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// get claims for my found items
claimApp.get(
    "/received",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // find items posted by logged-in user
            const items = await ItemModel.find({
                postedBy: req.user?.id,
                type: "FOUND"
            })
            // get item ids
            const itemIds = items.map(item => item._id)
            // find claims for those items
            const claims = await ClaimModel.find({
                itemId: { $in: itemIds }
            })
            .populate("itemId")
            .populate("claimantId", "-password")
            .sort({ createdAt: -1 })
            // send response
            res.status(200).json({
                message: "Received claims retrieved successfully",
                payload: claims
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// approve claim
claimApp.put(
    "/:claimId/approve",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get claim id
            const { claimId } = req.params
            // find claim
            const claim = await ClaimModel.findById(claimId)
            // claim not found
            if (!claim)
                return res.status(404).json({
                    message: "Claim not found"
                })
            // find item
            const item = await ItemModel.findById(claim.itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only item owner can approve claim
            if (
                item.postedBy.toString() !== req.user?.id &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to approve this claim"
                })
            // check claim status
            if (claim.status !== "PENDING")
                return res.status(400).json({
                    message: "Claim has already been processed"
                })
            // verify answer
            if (
                claim.answer.trim().toLowerCase() !==
                item.verificationAnswer.trim().toLowerCase()
            )
                return res.status(400).json({
                    message: "Verification answer is incorrect"
                })
            // approve claim
            claim.status = "APPROVED"
            await claim.save()
            // update item status
            item.status = "CLAIMED"
            await item.save()
            // send response
            res.status(200).json({
                message: "Claim approved successfully",
                payload: claim
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)

// reject claim
claimApp.put(
    "/:claimId/reject",
    verifyToken("USER", "ADMIN"),
    async (req, res) => {
        try {
            // get claim id
            const { claimId } = req.params
            // find claim
            const claim = await ClaimModel.findById(claimId)
            // claim not found
            if (!claim)
                return res.status(404).json({
                    message: "Claim not found"
                })
            // find item
            const item = await ItemModel.findById(claim.itemId)
            // item not found
            if (!item)
                return res.status(404).json({
                    message: "Item not found"
                })
            // only item owner can reject claim
            if (
                item.postedBy.toString() !== req.user?.id &&
                req.user?.role !== "ADMIN"
            )
                return res.status(403).json({
                    message: "You are not authorized to reject this claim"
                })
            // check claim status
            if (claim.status !== "PENDING")
                return res.status(400).json({
                    message: "Claim has already been processed"
                })
            // reject claim
            claim.status = "REJECTED"
            await claim.save()
            // send response
            res.status(200).json({
                message: "Claim rejected successfully",
                payload: claim
            })
        } catch (err) {
            res.status(500).json({
                message: err.message
            })
        }
    }
)