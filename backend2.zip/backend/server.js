// server.js

import exp from 'express';
import { connect } from 'mongoose';
import { config } from 'dotenv';
import { commonApp } from './APIs/CommonAPI.js';
import { itemApp } from './APIs/ItemAPI.js';
import { claimApp } from './APIs/ClaimAPI.js';
import { matchApp } from './APIs/MatchAPI.js';
import cors from 'cors';
import cookieParser from 'cookie-parser';

config()

// express app
const app = exp()

app.use(cors({
    origin: "http://localhost:5173",
    credentials: true
}))

app.use(cookieParser())
app.use(exp.json())

// routes
app.use("/auth", commonApp)
app.use("/item-api", itemApp)
app.use("/claim-api", claimApp)
app.use("/match-api", matchApp)

// assign port number
const port = process.env.PORT || 4000
let isConnected = false

// connect to DB
const connectDB = async () => {
    if (isConnected) return
    try {
        await connect(process.env.DB_URL)
        isConnected = true
        console.log("DB connected")
    } catch (err) {
        console.error("DB connection error:", err.message)
        process.exit(1)
    }
};

// call DB to connect then server should run
const startServer = async () => {
    await connectDB();

    app.listen(port, () => {

        console.log(`Server running on port ${port}`);

    });

};


// after DB connect server should run
startServer();