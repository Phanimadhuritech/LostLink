// verifyToken.js

import { config } from 'dotenv'
import jwt from 'jsonwebtoken'
const { verify } = jwt
config()

export const verifyToken = (...allowedRoles) => {
    // verifyToken("USER", "ADMIN")
    return (req, res, next) => {
        try {
            // get token from cookie
            const token = req.cookies?.token
            // check if token exists
            if (!token)
                return res.status(401).json({
                    message: "Please login first"
                })
            // validate token
            const decodedToken = verify(
                token,
                process.env.SECRET_KEY
            )
            // check if user's role is allowed
            if (!allowedRoles.includes(decodedToken.role))
                return res.status(403).json({
                    message: "You are not authorized"
                })
            // add decoded token to request
            req.user = decodedToken
            // move to next middleware/controller
            next()
        } catch (err) {
            res.status(401).json({
                message: "Invalid token"
            })
        }
    }

}