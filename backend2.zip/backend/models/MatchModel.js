// MatchModel.js

import { Schema, Types, model } from "mongoose";

const matchSchema = new Schema({
    lostItemId: {
        type: Types.ObjectId,
        ref: "item",
        required: [true, "Lost item required"]
    },
    foundItemId: {
        type: Types.ObjectId,
        ref: "item",
        required: [true, "Found item required"]
    },
    matchScore: {
        type: Number,
        required: [true, "Match score required"],
        min: 0,
        max: 100
    },
    matchedFields: {
        type: [String],
        default: []
    },
    status: {
        type: String,
        enum: ["PENDING", "CONFIRMED", "REJECTED"],
        default: "PENDING"
    }
}, {
    timestamps: true,
    versionKey: false
})

export const MatchModel = model("match", matchSchema)