// ItemModel.js

import { Schema, Types, model } from "mongoose";

const itemSchema = new Schema({
    itemName: {
        type: String,
        required: [true, "Item name required"],
        trim: true
    },
    type: {
        type: String,
        required: [true, "Item type required"],
        enum: ["LOST", "FOUND"]
    },
    category: {
        type: String,
        required: [true, "Category required"],
        enum: [
            "ELECTRONICS",
            "DOCUMENTS",
            "CLOTHING",
            "ACCESSORIES",
            "BOOKS",
            "KEYS",
            "BAGS",
            "OTHERS"
        ]
    },
    description: {
        type: String,
        required: [true, "Description required"],
        trim: true
    },
    location: {
        type: String,
        required: [true, "Location required"],
        trim: true
    },
    date: {
        type: Date,
        required: [true, "Date required"]
    },
    image: {
        type: String
    },
    postedBy: {
        type: Types.ObjectId,
        ref: "user",
        required: [true, "User required"]
    },
    status: {
        type: String,
        enum: ["ACTIVE", "MATCHED", "CLAIMED", "RETURNED"],
        default: "ACTIVE"
    },
    verificationQuestion: {
        type: String,
        trim: true
    },
    verificationAnswer: {
        type: String,
        trim: true
    }
}, {
    timestamps: true,
    versionKey: false
})

export const ItemModel = model("item", itemSchema)