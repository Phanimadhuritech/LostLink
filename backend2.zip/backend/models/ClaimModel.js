// ClaimModel.js

import { Schema, Types, model } from "mongoose";

const claimSchema = new Schema({
    itemId: {
        type: Types.ObjectId,
        ref: "item",
        required: [true, "Item required"]
    },
    claimantId: {
        type: Types.ObjectId,
        ref: "user",
        required: [true, "Claimant required"]
    },
    answer: {
        type: String,
        required: [true, "Verification answer required"],
        trim: true
    },
    status: {
        type: String,
        enum: ["PENDING", "APPROVED", "REJECTED"],
        default: "PENDING"
    },
    remarks: {
        type: String,
        trim: true
    }
}, {
    timestamps: true,
    versionKey: false
})

export const ClaimModel = model("claim", claimSchema)